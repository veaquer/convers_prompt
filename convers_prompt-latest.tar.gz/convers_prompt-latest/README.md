# Convertor app written in Rust ( Works only in linux )
__**convers-prompt**__ - prompt quick access gui app, that use convers magic_convert

![ray_translator_showcase](https://github.com/user-attachments/assets/e99ee935-b713-40ab-b370-c7103f0bcc94)


# Installation

## Archlinux
```
yay -S convers_prompt
```

## Other distros
Build from source.
